<?php
/**
 * ld Basic widgetssss
 */
use \Elementor\Widget_Base;
class ld_Basic_widgets extends Widget_Base {



	/**
	 * Get widget name.
	 */
	public function get_name() {
		return 'ld_Basic_widget';
	
}


	/**
	 * Get widget title.
	 */
	public function get_title() {
		return __( 'Ld Fast Test', 'ld_ele_textdomain' );
	}



	/**
	 * Get widget icon.
	 */
	public function get_icon() {
		return 'fa fa-battery-three-quarters';
	}



	/**
	 * Get widget categories.
	 */
	public function get_categories() {
		return [ 'ld-custom-cat' ];
	}


	
	/**add Stylesheet  Dependency in weidget */
	public function get_style_depends(){
		return ["ld-custom-sytle"]; 
	}



	/**add Javascript Dependency in weidget */
	public function get_script_depends(){  
		return ["ld-custom-js"];
		
	}


	// Registert contorls
//start Content paragraph
	
//End Register control section

//start render

	protected function render(){
		$settings = $this->get_settings_for_display();
		?>





<!-- html code here -->



<?php

		
	}






}